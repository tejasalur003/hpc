#include<bits/stdc++.h>
#include<omp.h>

using namespace std;
using namespace std :: chrono;

void seq_operations(vector<int> &arr, int &min_val, int &max_val, long long &sum, double &avg){
    min_val = INT_MAX;
    max_val = INT_MIN;
    sum = 0ll;
    for(int i=0;i<arr.size();i++){
        min_val = min(min_val, arr[i]);
        max_val = max(max_val, arr[i]);
        sum = sum+arr[i];        
    }
    avg = double(sum)/double(arr.size());
}

void parallel_operations(vector<int> &arr, int &min_val, int &max_val, long long &sum, double &avg){
    min_val = INT_MAX;
    max_val = INT_MIN;
    sum = 0ll;

    #pragma omp parallel for reduction(min : min_val) reduction(max:max_val) reduction(+ : sum)
    for(int i=0;i<arr.size();i++){
        min_val = min(min_val, arr[i]);
        max_val = max(max_val, arr[i]);
        sum = sum+arr[i];
    }
    avg = double(sum)/double(arr.size());
}




int main(){
    vector<int> vec;
    for(int i=1;i<=100000000;i++) {
        int temp = rand()%10000000;
        vec.push_back(temp);
    }

    int min_val, max_val;
    long long int sum;
    double avg;

    double t1 = omp_get_wtime();
    auto start = high_resolution_clock :: now();
    seq_operations(vec, min_val, max_val, sum, avg);
    double t2 = omp_get_wtime();
    auto end = high_resolution_clock :: now();
    cout<<"SEQUNETIAL ANALYSIS"<<endl;
    cout<<"Time elapsed : "<<t2-t1<<endl;
    cout<<"High-resolution : "<<duration_cast<milliseconds>(end-start).count()<<endl;
    cout<<"Min : "<<min_val<<endl;
    cout<<"Max : "<<max_val<<endl;
    cout<<"Sum : "<<sum<<endl;
    cout<<"Average : "<<avg<<endl;

    min_val = 0, max_val=0, sum=0, avg=69;

    double t3 = omp_get_wtime();
    start = high_resolution_clock :: now();
    parallel_operations(vec, min_val, max_val, sum, avg);
    double t4 = omp_get_wtime();
    end = high_resolution_clock :: now();
    cout<<"Parallel ANALYSIS"<<endl;
    cout<<"Time elapsed : "<<t4-t3<<endl;
    cout<<"High-resolution : "<<duration_cast<milliseconds>(end-start).count()<<endl;
    cout<<"Min : "<<min_val<<endl;
    cout<<"Max : "<<max_val<<endl;
    cout<<"Sum : "<<sum<<endl;
    cout<<"Average : "<<avg<<endl;




    return 0;
}