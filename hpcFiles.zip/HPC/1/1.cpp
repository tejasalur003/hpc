#include<bits/stdc++.h>
#include<omp.h>

using namespace std;
using namespace std::chrono;


class Graph{
    public:
    int n;
    vector<vector<int>> adj;
    vector<bool> vis;

    Graph(int sz){
        n = sz;
        vis.resize(sz);
        adj.resize(sz);
    }

    void reset_vis(){
        for(int i=0;i<n;i++) vis[i]=0;
    }

    void add_edge(int u, int v){
        adj[u].push_back(v);
        adj[v].push_back(u);
    }


    void seq_BFS(int src){
        queue<int> q;

        vis[src]=1;
        q.push(src);

        while(!q.empty()){
            int cur = q.front(); q.pop();
            cout<<cur<<" ";

            for(auto it : adj[cur]){
                if(vis[it]==false){
                    vis[it] = 1;
                    q.push(it);
                }
            }
        }
    }

    void seq_DFS(int src){
        stack<int> s;
        s.push(src);
        vis[src] = 1;
        while(!s.empty()){
            int cur = s.top(); s.pop();
            cout<<cur<<" ";
            for(auto it : adj[cur]){
                if(vis[it]==0){
                    vis[it] = 1;
                    s.push(it);
                }
            }
        }
    }


    void parallel_BFS(int src) {
        queue<int> q;
        q.push(src);
        vis[src] = 1;
    
        while (!q.empty()) {
            int lvl_sz = q.size();
            vector<int> cur_lvl;
            for (int i = 0; i < lvl_sz; ++i) {
                int cur = q.front(); q.pop();
               cout<<cur<<" ";
                cur_lvl.push_back(cur);
            }
    
            vector<int> global_to_push;
    
            #pragma omp parallel
            {
                vector<int> local_to_push;
    
                #pragma omp for nowait
                for (int i = 0; i < lvl_sz; ++i) {
                    int cur = cur_lvl[i];
                    for (int neighbor : adj[cur]) {
                        bool unvisited = false;
    
                        #pragma omp critical(vis_check)
                        {
                            if (!vis[neighbor]) {
                                vis[neighbor] = 1;
                                unvisited = true;
                            }
                        }
    
                        if (unvisited) {
                            local_to_push.push_back(neighbor);
                        }
                    }
                }
    
                #pragma omp critical(push_merge)
                {
                    global_to_push.insert(global_to_push.end(), local_to_push.begin(), local_to_push.end());
                }
            }
    
            for (int x : global_to_push) {
                q.push(x);
            }
        }
    }
    

    void parallelDFS(int start)
    {
        stack<int> s;
        s.push(start);
        vis[start] = true;

        while (!s.empty())
        {
            int node = s.top();
            s.pop();
            cout<<node<<" ";

            vector<int> neighbors = adj[node];
            
            #pragma omp parallel for
            for (int i = 0; i < neighbors.size(); ++i){
                int neighbor = neighbors[i];
                if (!vis[neighbor]){
                    #pragma omp critical
                    {
                        if (!vis[neighbor]){
                            s.push(neighbor);
                            vis[neighbor] = true;
                        }
                    }
                }
            }
        }
    } 
    
    

  

};



int main(){

    // for(int i=0;i<10;i++){
    //     int temp = rand()%10;
    //     cout<<temp<<" ";
    // }cout<<endl;

    Graph g(7);

    g.add_edge(0,1);
    g.add_edge(0,2);
    g.add_edge(1,4);
    g.add_edge(2,4);
    g.add_edge(1,3);
    g.add_edge(3,5);
    g.add_edge(4,5);
    g.add_edge(5,6);

    // Graph g(100000);

    // // 1. Linear chain (connect every node to the next)
    // for (int i = 0; i < 99999; i++) {
    //     g.add_edge(i, i + 1);
    // }
    
    // // 2. Deterministic modular jumps (connect each node to i+3, i+5)
    // for (int i = 0; i < 99995; i++) {
    //     g.add_edge(i, i + 3);
    //     g.add_edge(i, i + 5);
    // }
    

    g.reset_vis();
    auto start = high_resolution_clock :: now();
    double t1 = omp_get_wtime(); 
    g.seq_BFS(0);
    auto end = high_resolution_clock :: now();
    double t2 = omp_get_wtime();
    cout<<"SEQ BFS : "<<duration_cast<microseconds>(end-start).count()<<endl;
    cout<<"Time wtime : "<<t2-t1<<endl;

    g.reset_vis();
    start = high_resolution_clock :: now();
    double t3 = omp_get_wtime();
    g.parallel_BFS(0);
    end = high_resolution_clock :: now();
    double t4 = omp_get_wtime();
    cout<<"PARALLEL BFS : "<<duration_cast<microseconds>(end-start).count()<<endl;
    cout<<"Time wtime : "<<t4-t3<<endl;


    g.reset_vis();
    start = high_resolution_clock :: now();
    double t5 = omp_get_wtime();
    g.seq_DFS(0);
    end = high_resolution_clock :: now();
    double t6 = omp_get_wtime();
    cout<<"SEQ DFS : "<<duration_cast<microseconds>(end-start).count()<<endl;
    cout<<"Time wtime : "<<t6-t5<<endl;


    g.reset_vis();
    start = high_resolution_clock :: now();
    double t7 = omp_get_wtime();
    g.parallelDFS(0);
    end = high_resolution_clock :: now();
    double t8 = omp_get_wtime();
    cout<<"PARALLEL DFS : "<<duration_cast<microseconds>(end-start).count()<<endl;
    cout<<"Time wtime : "<<t8-t7<<endl;








    return 0;
}