#include<bits/stdc++.h>
#include<omp.h>

using namespace std;
using namespace std:: chrono;


void seq_bubbleSort(vector<int> &arr){
    int n = arr.size();
    for(int i=0;i<n-1;i++){
        for(int j=0;j<n-i-1;j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);
            }
        }
    }
}


void parallel_bubble_sort(vector<int> &arr){
    int n = arr.size();
    for(int i=0;i<n;i++){
        if(i%2 == 0){ // EVEN 
            #pragma omp parallel for
            for(int j=0;j<n-1;j=j+2){
                if(arr[j] > arr[j+1]){
                    swap(arr[j], arr[j+1]);
                }
            }
        }
        else{     // ODD
            #pragma omp parallel for
            for(int j=1;j<n-1;j=j+2){
                if(arr[j] > arr[j+1]){
                    swap(arr[j], arr[j+1]);
                }
            }

        }
    }
}

void merge(vector<int> &arr, int l , int m, int r){
    int n1 = m-l+1, n2 = r-m;
    vector<int> v1(n1), v2(n2);
    for(int i=0;i<n1;i++){
        v1[i] = arr[i+l];
    }
    for(int i=0;i<n2;i++){
        v2[i] = arr[m+1+i];
    }
    int i=0,j=0,k=l;
    while(i<n1 && j<n2){
        if(v1[i] < v2[j]){
            arr[k] = v1[i];
            k++; i++;
        }
        else{
            arr[k] = v2[j];
            k++; j++;
        }
    }
    while(i<n1){
        arr[k] = v1[i];
        k++; i++;
    }
    while(j<n2){
        arr[k] = v2[j];
        k++; j++;
    }
}

void seq_MergeSort(vector<int> &arr, int l, int r){
    if(l<r){
        int m = l + (r-l)/2;
        seq_MergeSort(arr, l, m);
        seq_MergeSort(arr, m+1, r);

        merge(arr, l, m, r);
    }
}

void parallel_MergeSort(vector<int> &arr, int l, int r, int depth=0){
    if(l<r){
        int m = l + (r-l)/2;
        if(depth<=3){
            #pragma omp parallel sections
            {
                #pragma omp section
                parallel_MergeSort(arr, l, m, depth+1);
                #pragma omp section
                parallel_MergeSort(arr, m+1, r, depth+1);
            }
        }
        else{
            seq_MergeSort(arr, l, m);
            seq_MergeSort(arr, m+1, r);
            merge(arr, l, m, r);
        }
    }
}



void printArray(vector<int> & arr){
    for(auto it : arr){
     cout<<it<<" ";
    }
    cout<<endl;    
}



int main(){

    int sz = 50000;
    vector<int> arr;
    for(int i=0;i<sz;i++){
        int temp = rand()%50000;
        arr.push_back(temp);
    }
    
    vector<int> arr1 = arr, arr2 = arr, arr3=arr, arr4=arr;

    // cout<<"INTIAL :"<<endl;
    // printArray(arr);


    double t1 = omp_get_wtime();
    auto start = high_resolution_clock::now();
    seq_bubbleSort(arr1);
    double t2  = omp_get_wtime();
    auto end = high_resolution_clock::now();
    // printArray(arr1);
    cout<<"Seq Bubble Sort : "<<t2-t1<<endl;
    cout<<"high-res : "<<duration_cast<milliseconds>(end-start).count()<<endl;

    double t3 = omp_get_wtime();
    start = high_resolution_clock::now();
    parallel_bubble_sort(arr2);
    double t4 = omp_get_wtime();
    end = high_resolution_clock::now();
    //printArray(arr2);
    cout<<"Paralle Bubble Sort : "<<t4-t3<<endl;
    cout<<"high-res : "<<duration_cast<milliseconds>(end-start).count()<<endl;

    double t5 = omp_get_wtime();
    start = high_resolution_clock::now();
    seq_MergeSort(arr3, 0, sz-1);
    double t6 = omp_get_wtime();
    end = high_resolution_clock::now();
    // printArray(arr3);
    cout<<"Seq Merge Sort time : "<<t6-t5<<endl;
    cout<<"high-res : "<<duration_cast<milliseconds>(end-start).count()<<endl;


    double t7 = omp_get_wtime();
    start = high_resolution_clock::now();
    parallel_MergeSort(arr4, 0, sz-1);
    double t8 = omp_get_wtime();
    end = high_resolution_clock::now();
    // printArray(arr4);
    cout<<"Parallel Merge Sort time : "<<t8-t7<<endl;
    cout<<"high-res : "<<duration_cast<milliseconds>(end-start).count()<<endl;

    return 0;
}